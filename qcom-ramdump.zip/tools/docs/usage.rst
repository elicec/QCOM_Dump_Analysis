Usage
=====

::

 ramparse.py -o . -a /path/to/dumps
