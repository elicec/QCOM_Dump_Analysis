.. _`Writing Parsers`:

Writing Parsers
===============

.. autofunction:: parser_util.register_parser
   :noindex:
