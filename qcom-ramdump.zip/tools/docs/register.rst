.. _`register`:

register
========

.. automodule:: register
   :members:
