Hacking
=======

This section covers the LRDP's internal API.  It is intended for developers
looking to add their own parser plugin to the LRDP.

.. toctree::
   :maxdepth: 2

   writing_parsers
   ramdump
   gdbmi
   register
   sizes
   parser_util
