# ramdump-parser.sh

#! /bin/bash

echo ""
echo "Start ramdump parser.."

local_path=$PWD
ramdump=$local_path/$1
vmlinux=$local_path/$1/vmlinux
out=$local_path/$1/out

#gdb=/media/disk/otherdisk/work_ph/LA.BR.1.2.4-05310-8x16.0_SLM753_platform/prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9/bin/aarch64-linux-android-gdb
#nm=/media/disk/otherdisk/work_ph/LA.BR.1.2.4-05310-8x16.0_SLM753_platform/prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9/bin/aarch64-linux-android-nm
#objdump=/media/disk/otherdisk/work_ph/LA.BR.1.2.4-05310-8x16.0_SLM753_platform/prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9/bin/aarch64-linux-android-objdump

gdb=$local_path/gnu-tools/msm8909/arm-linux-androideabi-gdb
nm=$local_path/gnu-tools/msm8909/arm-linux-androideabi-gcc-nm
objdump=$local_path/gnu-tools/msm8909/arm-linux-androideabi-objdump

# git clone git://codeaurora.org/quic/la/platform/vendor/qcom-opensource/tools
ramparse_dir=$local_path/tools/linux-ramdump-parser-v2/
########################################################################################

echo "cd $ramparse_dir"
cd $ramparse_dir
echo ""

echo -e "python ramparse.py -v $vmlinux -g $gdb  -n $nm  -j $objdump -a $ramdump -o $out -x"
echo ""

# python 2.7.5
python2 ramparse.py --32-bit -v $vmlinux -g $gdb  -n $nm  -j $objdump -a $ramdump -o $out -x

cd $local_path
echo "out: $out"
echo ""
exit 0
